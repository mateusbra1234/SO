#ifndef MEMORIA_H
#define MEMORIA_H
#include <iostream>
#include <QList>
#include <QQueue>
#include "processo.h"
using namespace std;

class Memoria
{
private:
    QList<Processo> RAM;
    QQueue<Processo> fila_de_processos;
    int qntd_mem;
public:
    Memoria();
    Memoria(QList<Processo> RAM,int qntd_mem);
    QList<Processo> getRAM() const;
    void setRAM(const QList<Processo> &value);
    int getQntd_mem() const;
    void setQntd_mem(int value);
    void inicializar_RAM(int qntd_mem);
    void first_fit();
    QQueue<Processo> getFila_de_processos() const;
    void setFila_de_processos(const QQueue<Processo> &value);
    void inicializar_Fila(int num_processos);
    void printar_RAM();
    bool ha_processos_na_RAM();
};

#endif // MEMORIA_H
