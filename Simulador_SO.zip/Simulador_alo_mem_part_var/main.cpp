#include <iostream>
#include <QQueue>
#include <QList>

using namespace std;

#include "processo.h"
#include "memoria.h"

int main()
{
    srand(time(nullptr));
    Memoria memoria;
    int qntd_mem = 1024;
    int num_processos = 100;
    cout<<"ESTE TRABALHO FOI FEITO COM FIRST FIT COMO ALGORITMO\n";
    cout<<"Digite a quantidade de memoria RAM:\n";
    cin>>qntd_mem;
    cout<<"Digite a quantidade de processos:\n";
    cin>>num_processos;
    memoria.inicializar_RAM(qntd_mem);
    memoria.inicializar_Fila(num_processos);
    memoria.first_fit();

    return 0;
}
