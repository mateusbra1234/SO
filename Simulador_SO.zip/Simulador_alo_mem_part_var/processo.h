#ifndef PROCESSO_H
#define PROCESSO_H
#include <iostream>
using namespace std;

class Processo
{
private:
    bool processo;
    string nome;
    int tempo_execucao;
    int tamanho;
public:
    Processo();
    Processo(bool processo,string nome,int tempo_execucao,int tamanho);
    bool getProcesso() const;
    void setProcesso(bool value);
    string getNome() const;
    void setNome(const string &value);
    int getTempo_execucao() const;
    void setTempo_execucao(int value);
    int getTamanho() const;
    void setTamanho(int value);
};

#endif // PROCESSO_H
