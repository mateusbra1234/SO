#include "processo.h"

bool Processo::getProcesso() const
{
    return processo;
}

void Processo::setProcesso(bool value)
{
    processo = value;
}

string Processo::getNome() const
{
    return nome;
}

void Processo::setNome(const string &value)
{
    nome = value;
}

int Processo::getTempo_execucao() const
{
    return tempo_execucao;
}

void Processo::setTempo_execucao(int value)
{
    tempo_execucao = value;
}

int Processo::getTamanho() const
{
    return tamanho;
}

void Processo::setTamanho(int value)
{
    tamanho = value;
}

Processo::Processo()
{

}
Processo::Processo(bool processo,string nome,int tempo_execucao,int tamanho)
{
    this->processo = processo;
    this->nome = nome;
    this->tempo_execucao = tempo_execucao;
    this->tamanho = tamanho;
}
