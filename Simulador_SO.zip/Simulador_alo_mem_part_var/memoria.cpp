#include "memoria.h"
#include "processo.h"

QQueue<Processo> Memoria::getFila_de_processos() const
{
    return fila_de_processos;
}

void Memoria::setFila_de_processos(const QQueue<Processo> &value)
{
    fila_de_processos = value;
}

Memoria::Memoria()
{
}
Memoria::Memoria(QList<Processo> RAM, int qntd_mem)
{
    this->RAM = RAM;
    this->qntd_mem = qntd_mem;
}
QList<Processo> Memoria::getRAM() const
{
    return RAM;
}

void Memoria::setRAM(const QList<Processo> &value)
{
    RAM = value;
}

int Memoria::getQntd_mem() const
{
    return qntd_mem;
}

void Memoria::setQntd_mem(int value)
{
    qntd_mem = value;
}

void Memoria::inicializar_RAM(int qntd_mem)
{
    this->RAM.append(*new Processo(false,"Vazio",0,qntd_mem));
}


void Memoria::inicializar_Fila(int num_processos){
    string nome_do_processo;
    int num = 1;
    string num_proc;
    int ciclos = rand() % 40;
    int tam = rand() % 200;
    for(int i=0;i<num_processos;i++){
        num_proc = std::to_string(num);
        nome_do_processo = "Processo"+num_proc;
        num++;
        while(ciclos<=0||tam<=0){
              ciclos = rand() % 40;
              tam = rand()% 200;
    }
        fila_de_processos.enqueue(*new Processo(true,nome_do_processo,ciclos,tam));

    }
}

void Memoria::printar_RAM(){

    cout<<"\n\n\n\n\n\n\n\n\t\t\t MEMORIA RAM:\n\n\n\n";
    cout<<"Tamanho       Memoria Ocupada       Ciclos      Processo       Fila\n\n";
    for(int i=0;i<RAM.size();i++){
        cout<<RAM.at(i).getTamanho()<<"                 "<<RAM.at(i).getProcesso()<<"                 "<<RAM.at(i).getTempo_execucao()<<"          "<<RAM.at(i).getNome()<<"        ";
        if(i<fila_de_processos.size()){
                cout<<fila_de_processos.at(i).getNome();
        }
        cout<<"\n\n";
    }
}

bool Memoria::ha_processos_na_RAM(){
    if(RAM.size()==1){
        if(RAM.first().getProcesso()==false){
            return false;
        }
    }
    return true;
}
void Memoria::first_fit()
{


        printar_RAM();
    do{



         for(int i=0;i<RAM.size();i++){

         if(RAM.at(i).getProcesso() == true){

             RAM.operator[](i).setTempo_execucao(RAM.operator[](i).getTempo_execucao() - 1);

             if(RAM.at(i).getTempo_execucao() == 0){

                 RAM.operator[](i).setNome("Vazio");
                 RAM.operator[](i).setProcesso(false);

             }
         }
         }



//criacao de processo
         for(int i=0;i < RAM.size();i++){
             if(fila_de_processos.isEmpty()==true){
                 break;
             }
             if(RAM.at(i).getProcesso() == false){

                 if(RAM.at(i).getTamanho() >= fila_de_processos.head().getTamanho()){
                     RAM.operator[](i).setTamanho(RAM.operator[](i).getTamanho() - fila_de_processos.head().getTamanho());
                        if(RAM.at(i).getTamanho()==0){
                            RAM.removeAt(i);
                        }
                     RAM.insert(i,fila_de_processos.dequeue());
                     break;
                 }

             }

         }

         for(int i=0; i< RAM.size();i++){
             if(i>0){
                 if(RAM.at(i).getProcesso() == false && RAM.at(i-1).getProcesso() == false){
                     RAM.operator[](i).setTamanho(RAM.operator[](i).getTamanho()+RAM.operator[](i-1).getTamanho());
                     RAM.removeAt(i-1);
                 }
             }
                 if(i<RAM.size()-1){
                 if(RAM.at(i).getProcesso() == false && RAM.at(i+1).getProcesso() == false){
                     RAM.operator[](i).setTamanho(RAM.operator[](i).getTamanho()+RAM.operator[](i+1).getTamanho());
                     RAM.removeAt(i+1);
                 }
                 }
             }

    getchar();
    printar_RAM();

     }while(fila_de_processos.isEmpty() == false || ha_processos_na_RAM());
}
